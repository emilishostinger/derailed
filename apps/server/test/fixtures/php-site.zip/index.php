<?php
$now = date('Y-m-d H:i:s');
$mysqli = function_exists('mysqli_connect') ? 'yes' : 'no';
?>
<!doctype html>
<title>Dropped PHP site</title>
<h1>Hello from a zip</h1>
<p>PHP <?= phpversion() ?>, rendered at <?= $now ?>.</p>
<p>mysqli available: <?= $mysqli ?></p>
<p>DERAILED_PROOF_OK</p>
